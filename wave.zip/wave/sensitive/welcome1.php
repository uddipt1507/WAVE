<?php

?>

<html>
<head>
	<title>Welcome page</title>
</head>
<body>
	<center><h1>Welcome</center>

<a href="logout1.php">Logout</a>

</body>
</html>