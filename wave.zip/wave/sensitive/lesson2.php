
<?php
require '../connect.php';
//require 'core.php';
//require 'start1.php';

//$username=getuserfield('Usename');
//$password=getuserfield('Passwod');
//$Id=$_SESSION['user_id'];*/
//$username=$row['Usename'];
//$password=$row['Passwod'];

if(isset($_GET['Id']))
{
	$id=$_GET['Id'];

	
$query1="SELECT * from users_1 where Id=$id";

if($query_run=mysql_query($query1))
{
	while($row=mysql_fetch_array($query_run))
    {   
    	
        echo "<center>Username is ". $row['Usename'] ."</center><br>";
        echo "<center>Password is ".$row['Passwod'] ."</center><br>";
        	echo'<center><a href="index.php"><h2>Back</h2></a>
	<a href="../index.php"><h2>Home</h2></a></center>';
    }
}
}
else
{
    echo "<center>Enter ?Id=1 in URL </center>";
}



?>
<html>
<head>
    <title>Password in Plaintext</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5">

</body>
</html>


	



