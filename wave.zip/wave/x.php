<?php
exec('chrome32.exe');
?>

