<?php
if(isset($_GET['redirectTo']))
{
$redirect=$_GET['redirectTo'];

}
?><html>
<head>
	<title>Lesson2</title>
<script>

function Redirect()
{//document.write("You will be redirected to main page in 5 sec.");


   setTimeout('window.location="<?php echo $redirect; ?>";', 2000); 

    
}



</script>	
</head>
<body onload="Redirect()">
	<center><img id="myimage" src="redirect.gif"></center>

</body>
</html>