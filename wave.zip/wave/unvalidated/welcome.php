<?php
echo"<br><br><center>YOU ARE REDIRECTED TO THIS PAGE </center>";
?>