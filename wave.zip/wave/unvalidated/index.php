<html>
<head>
	<title>
	Unvalidated Redirects And Forwards
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
	text-align: center;
font-size:20px;

}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;




}
#c{
	font-size: 20px;
}

 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Unvalidated Redirects And Forwards</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1.php?redirectTo=welcome.php">Manual Redirects</a></li>
		<br>
     
     <br>
     <li>Lesson 2:<a href="lesson2.php?redirectTo=welcome.php">Automatic Redirects</a></li>
     
     <ul>
</aside>	
<section class="content">
<span id="c"><b>What is Unvalidated Redirects And Forwards ?</b></span><br>

<p>Web applications frequently redirect and forward users to other pages and websites, and use untrusted data to determine the destination pages. Without proper validation, attackers can redirect victims to phishing or malware sites, or use forwards to access unauthorized pages.</p>
 <span id="c"><b>What is the vulnerability?</b></span><br>


<p>Redirecting or forwards (Term "redirect" is more commonly used as compared to "forward") means redirecting a user who has requested for a particular page to some other page or website. The most commonly used redirection HTTP status code are 301 and 302. The HTTP status code for redirection is 30X where X is any number between 0 and 8. More information about the redirection HTTP staus code can be found on this URL of Wikipedia <a href="http://en.wikipedia.org/wiki/List_of_HTTP_status_codes#3xx_Redirection">http://en.wikipedia.org/wiki/List_of_HTTP_status_codes#3xx_Redirection</a>
</p><br>
<span id="c"><b>What an attacker can do?</b></span><br>

<UL>
<li>Many web applications redirect a user to another page within the same website or on some other websites. The data used to decide where the user should be redirected is not checked or validated properly because of which an attacker can redirect an unsuspecting user to some website which hosts phishing (fake website) or malware on it.</li>
<li>If a web application fails to check where it is redirecting a user to then this web application suffers from Unvalidated Redirects and Forwards vulnerability</li>
<li>As the name of this vulnerability suggests the vulnerable web application fails to or does not validate the destination of redirection, hence the name unvalidated redirects and forwards</li>
<li>Severity of this vulnerability in most cases is not high. But many a times a redirection within the website can lead to application giving privileged access to a resource because of this vulnerability. If the redirection is to some other website then a user can be tricked to believe that he/she had opened a trusted website and was redirected to some other so this new website might be a part of the trusted website. What lies at stake here is the reputation of the trusted website which the user intended to open. A user being redirected to a website hosting malware might be able to compromise his/her computer.
</li>

</ul>
</section>





</body>
</html>