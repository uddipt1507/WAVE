<?php
if(isset($_GET['redirectTo']))
{
$redirect=$_GET['redirectTo'];
echo'<html>
<title>Login Page</title>
<body bgcolor="#e5e5e5">
<center><br><br>
<form action="'.$redirect.'" method="GET">

Username<input type="text" name="user" placeholder="Username">
Password<input type="password" name="pass" placeholder="Password">
<input type="submit" value="Login">
</form>
<h3>Change the redirectTo value in url ,press enter and then enter the values in the form </h3>
</center>
</body>
</html>';
}
?>