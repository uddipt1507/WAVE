<html>
<head>
	<title>User Credentials</title>
</head>
<body>
<table border=1;>
	<tr>
	<th>Username</th>
     <th>Password</th>
 </tr>
 <tr><td>admin</td>
  <td>password</td></tr>
 <tr><td>admin2</td>
  <td>password2</td></tr>
</table>	
<br><br>
For Click jacking-->
<br><br>
<table border=1>
	<tr>
	<th>Username</th>
     <th>Password</th>
 </tr>
 <tr><td>sam@gmail.com</td>
  <td>password</td></tr>
 <tr><td>rohit.m@gmail.com</td>
  <td>password2</td></tr>
</table>	

</body>
</html>