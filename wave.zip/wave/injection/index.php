<html>
<head>
	<title>
		Injection
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;
-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
	text-align: center;
font-size:20px;

}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;




}
#c{
	font-size: 20px;
}

 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Injection</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:Authentication Bypass</a></li>
		<ul>
     <li><a href="lesson1.php">Unsecured</a></li>
     <li><a href="auth_secure.php">Secured</a></li>
     </ul>

     <li>Lesson 2:Union Based</a></li>
     
     <ul>
     <li><a href="lesson2.php">Unsecured</a></li>
     <li><a href="sql_secure.php">Secured</a></li>
     </ul>
     <li>Lesson 3:<a href="lesson3.php" >Command Execution</a></li>
     <br>
     <ul>
</aside>	
<section class="content">
<span id="c"><b>What is Injecion?</b></span><br>

<p>Injection flaws, such as SQL, OS, and LDAP injection occur when untrusted data is sent to an interpreter as part of a command or query. The attacker's hostile data can trick the interpreter into executing unintended commands or accessing data without proper authorization.</p><br><br>
 <br><br><br><br>
 <span id="c"><b>What is the vulnerability?</b></span><br>


<p>Injection is a type of web application vulnerability in which malicious input is sent to the server side application for processing. This malicious input is created in such a manner that the backend application can be manipulated in one or other manner. Injection vulnerability includes SQL injection, OS injection, LDAP injection, XML injection, etc. SQL injection is one of the most exploited vulnerability using which database is compromised leading to database enumeration, in worst case server compromise.
</p>
<span id="c"><b>What an attacker can do?</b></span><br>

<UL>
<li>User controlled input points which are used as an input by the server application are tested for injection vulnerabilities.</li>
<li>The response received after injection is processed to find out if the injection worked properly in the backend and desired results have been achieved or not.</li>
<li>In some cases blind injection has to be performed means we are not aware if the injection is working or not.</li>
</ul>
</section>





</body>
</html>