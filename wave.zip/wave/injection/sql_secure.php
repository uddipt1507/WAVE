<?php
$host='localhost';
$user='root';
$pass='';
$dbname='project';
//connecting
$conn= new mysqli($host,$user,$pass,$dbname);

//query
if(isset($_REQUEST['Id']) && !empty($_REQUEST['Id']))
{

$stmt=$conn->prepare("Select GEnder from union1 where Id=?");
$id=$_REQUEST['Id'];

$stmt->bind_param('i',$id);
$stmt->execute();
$stmt->bind_result($result);
while($stmt->fetch())
{
	echo $result."<br>";
}

/*$query="SELECT * from user where Id='$id'";
if (!$result=$conn->query($query)) {

	die("Error connecting database ".$conn->error);
	
}
else
{
	while($row=$result->fetch_assoc())
	{
      echo '<br>'.$row['FName'].'<br>';

	}
}
}*/
}

?>
<html>
<title>Sql Injection Prevention</title>
<body bgcolor=#e5e5e5>
	<br><br><br><br>
	<center>
	<form action="">
		Enter id :<input type="text" name="Id" placeholder="Enter value here">
<input type="submit" value="Submit">
</form>
</center>
<a href="sql_secure.php?Id=1">Click here for Id=1</a><br>
<a href="sql_secure.php?Id=2">Click here for Id=2</a>
	</body>
</html>