<?php
require '../core.php';
if(!loggedin())
{
	header('Location:auth_secure.php');
}

?>

<html>
<head>
	<title>Welcome page</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >
	<center><h1>Welcome</center>

<a href="logout_s.php">Logout</a>

</body>
</html>