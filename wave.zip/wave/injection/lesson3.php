<html>
<head>
	<title>Command Execution</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >
<form action="" mehtod="POST">
<input type="text" name="ip" placeholder="Enter ip here">
<input type="submit" value="SUbmit">
</form>
</body>
</html>
<?php
if(isset($_GET['ip']))
{  $host=$_GET['ip'];
	exec ("ping -n 1 -w 1 $host", $ping_output,$result);

// Loop through the returned lines from the output
$i=0;
if($result==0)
{
while($i < count($ping_output)) {
  echo "Line $i: " . $ping_output[$i] . "<br>";
  $i++;
}
}
else
{
	echo "Ping Unsuccessfull";
}
}
?>
