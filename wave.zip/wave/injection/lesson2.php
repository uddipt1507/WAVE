 <?php
require '../connect.php';
if(isset($_REQUEST['id'])) 
{
	
if(!empty($_REQUEST['id']))

{$id=$_REQUEST['id'];
$query="SELECT * from union1 where Id='$id'";
$query_run=mysql_query($query) or die(mysql_error());
if($query_run)
{
    if(mysql_num_rows($query_run)==0)
    	echo "Invalid Id";
    else
    {  
       $user_id=mysql_result($query_run,0,'Id');
       $interest=mysql_result($query_run,0,'Interest');
       $gender=mysql_result($query_run,0,'Gender');
        echo "Interest : $interest ";
    	echo "Gender : $gender";
    	$_SESSION['user_id']=$user_id;
     }

}

}
else
{	
echo "Enter the Id";
}
}


?>
<html>
<title>Union Based Injecion</title>
<body bgcolor=#e5e5e5>
	<br><br><br><br>
	<center>
	<form action="lesson2.php" method="POST">
Enter id :<input type="text" name="id" placeholder="Enter value here">
<input type="submit" value="Submit">
</form>

<a href="index.php"><h2>Back</h2></a>
	<a href="../index.php"><h2>Home</h2></a>
</center>
<a href="lesson2.php?id=1">Click here for Id=1</a><br>
<a href="lesson2.php?id=2">Click here for Id=2</a>
	</body>
</html>
