<?php 
require '../core.php';
if(loggedin())
{
    echo 'you are logged in.<a href="logout.php">Logout</a>';
    die();
}

else
{
	$host='localhost';
    $user='root';
    $pass='';
    $dbname='project';
    $conn=new mysqli($host,$user,$pass,$dbname);
    if($conn->connect_error)
    {
        echo "Error in connecting to database";
    }

    $title="Authentication Bypass(Secured)";
    require '../login_post.php';
	if(isset($_POST['username']) && isset($_POST['password'])) 
{
	
if(!empty($_POST['username']) && !empty($_POST['password']))

{
if($query=$conn->prepare("SELECT Id from users_1 where Usename=? AND Passwod=?"))
 {
$username=$_POST['username'];
$password=$_POST['password'];
$query->bind_param('ss',$username,$password);
$query->execute();
//$query->bind_result($result);
$result = $query->get_result();

if($result->num_rows>0)
{  $_SESSION['user']=$username;
    header('Location:start_s.php'); 
}
else if($result->num_rows==0)
{
    echo "Invalid Username and Password";
}
/*if($query->fetch())
{
    header('Location:start.php');
}
else
{
    echo "Invalid Username and Password";
}*/
}

}
}
}
   



?>


