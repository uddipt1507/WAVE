<html>
<head>
	<title>Login Form</title>
	<link href = "login.css" rel="stylesheet">
</head>
<body bgcolor="#e5e5e5">
	<div class="login-form">
		<center>
		<h1>Login form</h1>
		
		<form action="#">
			<input type="text" name="username" placeholder="username">
			<input type="password" name="password" placeholder="password">

			<input type="submit" value="Log in">


		</form>
	</center>

	</div>		

</body>
</html>