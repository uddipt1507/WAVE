<?php
require '../core.php';
if(!loggedin())
{
	header('Location:lesson1.php');
}

?>

<html>
<head>
	<title>Welcome page</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >
	<center><h1>Welcome</center>

<a href="logout.php">Logout</a>

</body>
</html>