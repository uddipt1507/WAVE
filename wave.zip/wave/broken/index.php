<html>
<head>
	<title>
		Broken Authentication and Session Management
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
	text-align: center;
font-size:20px;

}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;




}
#c{
	font-size: 20px;
}

 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Broken Authentication and Session Management</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1.php" >Weak Login Credentials</a></li>
		<br>
     <li>Lesson 2:<a href="lesson2.php" >Session Flaws</a></li>
     <ul>
</aside>	
<section class="content">
<span id="c"><b>What is Broken Authentication and Session Management?</b></span><br>

<p>Application functions related to authentication and session management are often not implemented correctly, 
	allowing attackers to compromise passwords, keys, or session tokens, or to
 exploit other implementation flaws to assume other users? Identities.</p><br><br>
 <span id="c"><b>What is the vulnerability?</b></span><br>


<p>If the developer(s) of a web application have not implemented authentication mechanisms or recovery modules or session management properly then this web application suffers from Broken Authentication and Session Management vulnerability. 
	This type of vulnerability most commonly exists in login page, forgot password, change password, account settings, logout, pre and 
	post authentication sessions, etc.
</p>
<span id="c"><b>What an attacker can do?</b></span><br>

<UL>
<li>A web application having a login form not implementing account lockout (block further login attempts to an account) can be brute 
	forced with any username-password combination. This can be used to crack accounts with weak login credentials.</li>
<li>Forgot password is not implemented securely due to which a malicious user can receive another user's current password 
	or password reset link on his/her email.</li>
<li>Change password is not implemented securely due to which a malicious user can login into his account and change another user's password.</li>
<li>Pressing "logout" does not invalidate the user's session and clicking "Back" button opens up the account again.</li>
<li>The value of session cookie is same for pre and post authentication.</li>
 <li>The value of session cookie can be guessed easily or calculated by a malicious user.</li>
<li>A logged-in user's session does not timeout after a certian time period of no activity.</li>
<li>The user's login credentials are stored in plaintext in database. (Also part of A-6 Sensitive Data Exposure)</li>
<li>The user's login credentials are sent in plaintext over the network. (Also part of A-6 Sensitive Data Exposure)</li>
</ul>
</section>





</body>
</html>