<?php
session_start();

session_destroy();


header('Location:lesson2.php');
?>