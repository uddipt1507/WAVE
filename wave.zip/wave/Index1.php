<?php
$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';

if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project'))
{

echo'<body bgcolor="#e5e5e5"><br><br><center>
<a href="Reset.php">Create Database</a></center><br><br></body>';
exit("<center><b>Create database first</b></center>");
}
?>
<!doctype html>
<html>
	<head>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<title>
			Vulnerable Web Application
		</title>
		<link href = "index2.css" rel="stylesheet">
		<script type="text/javascript">
$(document).ready(function(){
    
        $("#a1").animate({left: '60px'});
        $("#a2").animate({left: '270px'});
        $("#a3").animate({right: '270px'});
        $("#a4").animate({right: '60px'});
        $("#a5").animate({left: '270px'});
        $("#a6").animate({right: '270px'});

         $("#a7").animate({left: '270px'});
        $("#a8").animate({right: '270px'});
        $("#a9").animate({left: '60px'});
        $("#a10").animate({left: '270px'});
        $("#a11").animate({right: '270px'});
        $("#a12").animate({right: '60px'});
    });
</script> 
	</head>
	<body>
		
		<div class = "page">
			
			
			<header class = "header">
				<h1>WEB APPLICATION VULNERABILITIES EXPLIANER</h1><br>
				<H2>W.A.V.E</H2><BR><BR>

			    <a href = "#"><div class = "li th"><span class = "hov"></span>
					<div class = "submenu tmenu">
                        <a href="injection/index.php" id="a1">Injection
                        </a>
                        <a href = "secure/index.php" id="a2">Security Misconfiguration
						</a>
						<a href = "sensitive/index.php" id="a3">Sensitive Data Exposure
						</a>
						
						<a href = "XSS/index.php" id="a4">Cross-Site Scripting (XSS)
						
						</a><br><br><br>
					
						<a href = "broken/index.php" id="a5">Broken Authentication and Session Management
					</a>
					
						<a href = "insecure/index.php" id="a6">Insecure Direct Object Reference
						
						</a><br><br><br>
                       <a href = "function/index.php" id="a7">Missing Function Level Access Control
						
					</a>

						
						
						<a href="unvalidated/index.php" id="a8">Unvalidated Redirects And Forwards
						</a><br><br><br>
						<a href="CSRF/index.php" id="a9">Cross-Site Request Forgery
						</a>
						<a href = "session/index.php" id="a10">Session Management
						</a>
						
						<a href = "Click_jack/index.php" id="a11">Click Jacking
						</a>
						<a href = "inclusion/index.php" id="a12">File Inclusion Vulnerability
						</a>
					</div>
					</div><br><br><br>
				
					
			
		
</header>
<div class="x"><form action="reset.php">
				<input type="submit" value="Reset Database">
			</form>
		</div>

<div class="y">
<form action="user.php">
				<input type="submit" value="Default user Credentials">
			</form></div>
			<br><br>




</body>
</html>





