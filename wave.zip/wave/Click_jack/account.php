<?php
require '../core.php';
if(!loggedin())
{
	header('Location:index.php');
}

?>
<html>
<head>
	<title>My Account</title>
<style>
#edit{
		text-align: right;
		background-color: #8FD8D8;
		border: 1px solid black;
		padding:10px;
	}
</style>
</head>
<body>
<div id="edit">
<center><h2>Welcome to your account</h2></center>

		<form action="edit.php" method="POST">
			<input type="hidden" name="Id" value="<?php echo $_SESSION['Id'];?>">
			<input type="submit" value="Edit Your Account">
		</form>
	</div>
<a href="logout.php">Logout</a>

</body>
</html>
