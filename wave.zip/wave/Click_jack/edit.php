<?php
session_start();
include '../connect.php';
if(isset($_SESSION['user']))
{
$id=$_SESSION['user'];
$query="Select * from jack where Id=$id";
$index=array("First Name","Last Name","Email","Password","Day","Month","Year","Gender");
if($query_run=mysql_query($query))
{
   $row=mysql_fetch_array($query_run);
   echo '<html>
   <title>Edit Page</title>
   <body>
   <a href="frame.php">Click here to see clickjacking</a>
   <form action="editit.php" method="POST" style="text-align:left;margin-left:25%;">
       <h2>Your Details</h2>
       <input type="hidden" name="Id" value='.$id.'>
		First Name&nbsp;<input type="text" name="fname" value="'.$row['1'].'">&nbsp;&nbsp;&nbsp;
		Last Name&nbsp;<input type="text" name="lname" value="'.$row['2'].'"><br><br>
		Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="email" value="'.$row['3'].'" size=60 ><br><br>
		Password&nbsp;&nbsp;<input type="text" name="password" value="'.$row['4'].'" size=60><br><br>
		<p><b>Birthday</b></p>
		<select name="day">
			<option value="'.$row['5'].'">'.$row['5'].'</option>';
			
			for($i=1;$i<=31;$i++)
			{
				echo '<option value='.$i.'>'.$i.'</option>';
			}
			
		echo '</select>
		<select name="month">
			<option value="'.$row['6'].'">'.$row['6'].'</option>
			<option value="January">January</option>
			<option value="February">February</option>
			<option value="March">March</option>
			<option value="April">April</option>
			<option value="May">May</option>
			<option value="June">June</option>
			<option value="July">July</option>
			<option value="September">September</option>
			<option value="October">October</option>
			<option value="November">November</option>
			<option value="December">December</option>
		</select>

		<select name="year">
			<option value="'.$row['7'].'">'.$row['7'].'</option>';
			
			for($i=2015;$i>=1905;$i--)
			{
				echo '<option value='.$i.'>'.$i.'</option>';
			}


		
		echo '</select><br><br>';
		
		echo '
		<input type="radio" name="gender" id="gender" value="Male" ';if($row['8']=="Male")echo "Checked"; echo '>Male &nbsp;&nbsp;
		<input type="radio" name="gender" id="gender" value="Female" ';if($row['8']=="Female")echo "Checked"; echo ' >Female<br><br>
		<input type="submit" name="submit" value="Edit">
	</form>
	<a href="account.php" style="margin-left:25%;">Back</a>
	</body>
	</html>
	';
   }
}
/*echo '<form action="" method="POST" style="text-align:left; margin-left:350px;">';
   for($i=0;$i<8;$i++)
   {
   	
   echo "$index[$i]";
   echo '&nbsp;<input type="text" name="'.$i.'" value="'.$row[$i].'"><br>';
}
echo '<br><input type="submit" value="Edit" name="submit"></form>';
die();
}
}*/

?>
