<?php
include '../connect.php';
$query1="Select count(*) from jack";
$result=mysql_query($query1);
$id=mysql_num_rows($result)+1;

if(isset($_POST['fname'])&& isset($_POST['day']) && isset($_POST['month']) && isset($_POST['year'])
&& isset($_POST['lname']) && isset($_POST['email']) 
	&& isset($_POST['password']) && isset($_POST['gender']) &&isset($_POST['Id']))
	{
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$password=$_POST['password'];
$id=$_POST['Id'];
$day=$_POST['day'];
$month=$_POST['month'];
$year=$_POST['year'];
$gender=$_POST['gender'];

$query="INSERT INTO `jack`(`Id`,`Fname`, `Lname`, `Email`, `Password`, `Day`, `Month`, `Year`, `Gender`) 
VALUES ('$id','$fname','$lname','$email','$password','$day','$month','$year','$gender')";
 $query_run=mysql_query($query) or die(mysql_error());
if($query_run=mysql_query($query))
{
	echo 'Profile created sucessfully';
}
else
{
	echo "Profile not created ";
}
}
else
{
	echo "Enter all the fields";
}


?>
<html>
<head>
	<title>Click Jacking</title>
	<style>
	#content{
		margin-left: 350px;
	}
	#signin
	{
		text-align: right;
		background-color: #8FD8D8;
		border: 1px solid black;
		padding:10px;
	}
	</style>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >
	<div id="signin">
		<form action="login1.php"><input type="submit" value="Log into existing account"></form>
	</div>
	<div id="content">
	<p><b>Create Your account</b></p>
	<form action="" method="POST">
		<input type="text" name="fname" placeholder="First Name">&nbsp;&nbsp;&nbsp;
		<input type="text" name="lname" placeholder="Last Name"><br><br>
		<input type="text" name="email" placeholder="Email" size=47.5 ><br><br>
		<input type="password" name="password" placeholder="Password" size=47.5><br><br>
		<input type="hidden" name="Id" value="<?php echo $id;?>">
		<p><b>Birthday</b></p>
		<select name="day">
			<option value="Day">Day</option>
			<?php
			for($i=1;$i<=31;$i++)
			{
				echo '<option value='.$i.'>'.$i.'</option>';
			}
			?>
		</select>
		<select name="month">
			<option value="Month">Month</option>
			<option value="January">January</option>
			<option value="February">February</option>
			<option value="March">March</option>
			<option value="April">April</option>
			<option value="May">May</option>
			<option value="June">June</option>
			<option value="July">July</option>
			<option value="September">August</option>
			<option value="September">September</option>
			<option value="October">October</option>
			<option value="November">November</option>
			<option value="December">December</option>
		</select>

		<select name="year">
			<option value="Year">Year</option>
			<?php
			for($i=2015;$i>=1905;$i--)
			{
				echo '<option value='.$i.'>'.$i.'</option>';
			}

			?>
		</select><br><br>
		<input type="radio" name="gender" value="Male">Male &nbsp;&nbsp;
		<input type="radio" name="gender" value="Female">Female<br><br>
		<input type="submit" name="submit" value="Sign Up">
	</form>
</div>
<h3><a href="../index.php">Back</a></h3>
	</body>
	</html>