<?php
$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';

if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project'))
{header('Location:first.php');

echo'<body bgcolor="#e5e5e5"><br><br><center>
<a href="reset.php">Create Database</a></center><br><br></body>';
exit("<center><b>Create database first</b></center>");
}
?>
<!doctype html>
<html>
	<head>

		<title>
			Vulnerable Web Application
		</title>
		<link href = "index.css" rel="stylesheet">
		
	</head>
	<body>
		
		<div class = "page">
			
			
			<header class = "header">
				<h1>WEB APPLICATION VULNERABILITIES EXPLIANER</h1><br>
				<H2>W.A.V.E</H2><BR><BR>

			    <a href = "#"><div class = "li th"><span class = "hov"></span>
					<div class = "submenu tmenu">
                        <a href="injection/index.php"><div class="sub"><span >Injection</span>
                        </div></a>
                        <a href = "secure/index.php"><div class = "sub">Security Misconfiguration
						</div></a>
						<a href = "sensitive/index.php"><div class = "sub">Sensitive Data Exposure
						</div></a>
						
						<a href = "XSS/index.php"><div class = "sub">Cross-Site Scripting (XSS)
						
						</div></a><br><br>
					
						<a href = "broken/index.php"><div class = "sub">Broken Authentication and Session Management
						</div></a>
					
						<a href = "insecure/index.php"><div class = "sub">Insecure Direct Object Reference
						
						</div></a><br><br>
                       <a href = "function/index.php"><div class = "sub">Missing Function Level Access Control
						
						</div></a>

						
						
						<a href="unvalidated/index.php"><div class ="sub">Unvalidated Redirects And Forwards
						</div></a><br><br>
						<a href="CSRF/index.php"><div class ="sub">Cross-Site Request Forgery
						</div></a>
						<a href = "session/index.php"><div class = "sub">Session Management
						</div></a>
						
						<a href = "Click_jack/index.php"><div class = "sub">Click Jacking
						</div></a>
						<a href = "inclusion/index.php"><div class = "sub">File Inclusion Vulnerability
						</div></a><br><br>
						<a href = "x.php"><div class = "sub">Key Logger
						</div></a>
					</div>
					</div><br><br>
				
					
			
		
</header>
<div class="x"><form action="reset.php">
				<input type="submit" value="Reset Database">
			</form>
		</div>

<div class="y">
<form action="user.php">
				<input type="submit" value="Default user Credentials">
			</form></div>
			<br><br>



</body>
</html>





