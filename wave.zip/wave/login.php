<html>
<head>
	<style type="text/css">
	h1 {background-color: #ccc;
		-moz-border-radius: 5px;
		-webkit-border-radius: 5px;
		border: 1px solid #000;
		padding: 10px;" }
		.focus{
			background-color:#ccc;
		}
		</style>
		<script type = "text/javascript" src = "jq.js"></script>
		<script type = "text/javascript">
		$(document).ready(function(){
			$("input").focus(function() {
				$(this).addClass("focus");
			});
			
			$("input").blur(function() {
				$(this).removeClass("focus");
			});
		});
		</script>
	</head>
	<body bgcolor="#e5e5e5">
		<center>
		<h2>Enter to your Account</h2><br>
		
			<form action="" method="GET">
				Username<input type="text" name="username" placeholder="Username">
				Password<Input type="password" name="password" placeholder="Password">
				<input type="submit" value="Submit">
			</form>
			
			<br><br>
			<a href="index.php"><h2>Back</h2></a>
			<a href="../index1.html"><h2>Home</h2></a>
		</center>
	</body>
	</html>