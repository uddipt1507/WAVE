<html>
<head>
	<title>
		Insecure Direct Object Reference 
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
font-size:20px;
}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;
}
#c{
	font-size: 20px;
}
 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Insecure Direct Object Reference (IDOR)</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1.php" >Using GET</a></li>
		<br>
		<li>
     Lesson 2:<a href="lesson2.php" >Using POST</a></li>
    
 </ul>

</aside>	
<section class="content">
<span id="c"><b>What is Insecure Direct Object Reference (IDOR)?</b></span><br>

<p>A direct object reference occurs when a developer exposes a reference to an internal implementation object, such as a file, directory, or database key. 
	Without an access control check or other protection, attackers can manipulate these references to access unauthorized data.
</p>

<br><br><br>
<span id="c"><b>What is the vulnerability?</b></span><br>
<p>Insecure Direct Object Reference or IDOR is a type of web application vulnerability using which a user can access the resources 
or details of another user for which he/she is not authorized. In other words if a web application fails to check if a user 
if authorized to access a resource or not then it suffers from IDOR. Do note here that a malicious is able to access resources 
of another USER only. Both have the same level of access in case of IDOR. If the level of access increases then it will change 
to A-7 Missing Function-level Access Control.</p>
<span id="c"><b>What an attacker can do?</b></span><br>
<ul>
	<li>A web application allows an authenticated user to update his account information like email address, phone number, gender etc. The method implemented by the application to update a user's information is 
	flawed due to which a malicious user can modify a field's value allowing him/her to update or view details or both of another user.</li>
<li>The field in use to update or show user's data might be a GET parameter or POST parameter or hidden field, even a cookie value can be used.</li>
<li>HTML comments might have been left behind by mistake. So HTML source should be checked thoroughly to find any entry point or useful information.</li>
<li>Testing has to be done on all those fields which contain information related to a particular user and are used as input by the server side application.</li>
</ul>	

</section>

</body>
</html>