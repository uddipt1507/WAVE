<?php
require '../core.php';
require '../connect.php';

if(!loggedin())
{
  header("Location:lesson2.php");
}
$query="SELECT * from users_1 where Id='".$_SESSION['user']."' limit 0,1;";

if($query_run=mysql_query($query))
{ while($row=mysql_fetch_array($query_run))
{	
 //echo '<a href="myaccount.php?id=$row[0]">My Account </a>';
 echo '<form action="myaccount2.php" method=POST>';
echo '<input type="hidden" name="Id" value="'.$row['Id'].'">';
 echo '<center><input type="submit" value="My Account">';
 echo '</form><br><br>';
 //echo "<a href='myaccount.php'>My Account</a><br>";
 echo "<a href='logout1.php'>Logout</a></center>";

}
}
?>
<html>
<title>Welcome page</title>

<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

</body>
</html>

