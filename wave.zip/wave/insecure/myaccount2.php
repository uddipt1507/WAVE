
<?php
//require 'core.php';
//require 'start1.php';
require '../connect.php';

//$username=getuserfield('Usename');
//$password=getuserfield('Passwod');
//$Id=$_SESSION['user_id'];*/
//$username=$row['Usename'];
//$password=$row['Passwod'];

if(isset($_POST['Id']))
{
	$id=$_POST['Id'];
	
	if(isset($_POST['username']) && isset($_POST['password'] ) )
{

$username_new=$_POST['username'];
$password_new=$_POST['password'];

$query="UPDATE users_1 SET Usename='$username_new',Passwod='$password_new' where Id='$id'";

/*$query="UPDATE `users_1` SET `Usename`='$username_new',`Passwod`='$password_new' WHERE Id='".$_SESSION['user_id']."'";*/
if($query_run=mysql_query($query))
	{   echo "<center>Updated Successfully</center><br>";
		/*echo "<center>Updated successfully</center><br>";
		$username=$username_new;
		$password=$password_new;*/
	}
}


$query1="SELECT * from users_1 where Id=$id";
if($query_run2=mysql_query($query1))
{
	echo "<center><form action='myaccount2.php' method=POST>";
                            echo "<br><table border='0'>";
                            if($row = mysql_fetch_array( $query_run2 ))
                            
                             {   echo "<tr><td>User ID</td><td><input type=text name=Id value='".$row['Id']."'></td></tr>";
                                echo "<tr><td>Username</td><td><input type=text name=username value='".$row['Usename']."'></td></tr>";
                                echo "<tr><td>Password</td><td><input type=text name=password value='".$row['Passwod']."'></td></tr>";
                            }
                        }
                    }
                    
                
                        else
                        {
                            echo "<font color=red>Invalid account</font>";
                        }
                    
                   
                    echo "</table><br>";
                    echo "<input type=submit value='Update'>";
                    echo "</form></center>";




?>
<html>
<head>
    <title>Myaccount</title>
</head>
<body bgcolor="#e5e5e5">
    <center>


	</center>

</body>
</html>



