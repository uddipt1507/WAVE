<?php 
require '../core.php';
if(loggedin())
{
	echo 'you are logged in.<a href="logout1.php">Logout</a>';
	die();
}

else
{
	require '../connect.php';
    $title="IDOR using POST";
    require '../login_post.php';
	if(isset($_POST['username']) && isset($_POST['password'])) 
{
	
if(!empty($_POST['username']) && !empty($_POST['password']))

{$username=$_POST['username'];
$password=$_POST['password'];
$query="SELECT Id from users_1 where Usename='$username' AND Passwod='$password'";

if($query_run=mysql_query($query))
{
    if(mysql_num_rows($query_run)==0)
    	echo "Invalid Username and Password";
    else if(mysql_num_rows($query_run)>=1)

    {  
    	$user_id=mysql_result($query_run, 0 ,Id);
    	$_SESSION['user']=$user_id;

    	header('Location:start2.php');
    }

}

}
else
{	
echo "Enter the fields";
}
}
}
?>

