<?php
if( $_FILES['fileToUpload']['name'] != "" )
{
   copy( $_FILES['fileToUpload']['name'], "/var/www/html" ) or 
           die( "Could not copy file!");
}
else
{
    die("No file specified!");
}
?>
