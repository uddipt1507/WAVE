<html>
<head>
	<title>
		Missing Function Level Access Control
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
font-size:20px;
}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;
}
#c{
	font-size: 20px;
}
 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Missing Function Level Access Control</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1/lesson1.php" >Unaunthenticated User
	Access to Admin</a></li>
		<br>
		<li>
     Lesson 2:<a href="lesson2/lesson2.php" >Aunthenticated User Access to Admin</a></li>
 </ul>

</aside>	
<section class="content">
<span id="c"><b>What is Missing Function Level Access Control?</b></span><br>

<p>Most web applications verify function level access rights before making that functionality visible in the UI. 
	However, applications need to perform the same access control checks on the server when each function is accessed. 
	If requests are not verified, attackers will be able to forge requests in order to access functionality without proper authorization.</p>


<br><br><br>
<span id="c"><b>What is the vulnerability?</b></span><br>
<p>Missing Function Level Access Control is a type of web application vulnerability in which the web
 application fails to check if a user trying to access a particular resource has the access level to access 
 that resource or not. If a low privileged user or normal user is able to access a resource or use a functionality 
 available only to higher privileged users or admin then the web application suffers from Missing Function Level Access Control. 
 Misconfiguration or flawed code is the root cause of this vulnerability.</p>
<p>Note that the user is able to access the resources available to higher privileged users only because the application fails 
	to check the access level allowed to the user trying to access a particular resource.</p>
<span id="c"><b>What an attacker can do?</b></span><br>
<ul>
<li> The administration panel or management console is accessible publicly and does not require any authentication for access.
 Any unauthenticated user can access this page then the web application is vulnerable to this vulnerability.</li>
<li> The administration panel or management console is NOT accessible publicly and but a normal user who is authenticated can 
	access high privileged page because it does not require any authentication for access. Any authenticated user can access this
	 page then the web application is vulnerable to this vulnerability.</li>
<li> Authorization with Access Level check is not performed properly due to which privileged functionality can be 
	accessed easily by an attacker</li>
</section>



</body>
</html>