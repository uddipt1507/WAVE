<?php
echo"<html><body bgcolor='#e5e5e5'></body></html>";
session_start();
if(!isset($_SESSION['user1']) && empty($_SESSION['user1']))
{
	header("Location:lesson2.php");
}
else
{   
	echo "<a href='admin.php'>Admin</a> <br>";
	echo "<a href='logout.php'>Logout</a>";
}

?>
<html>
<head>
	<title>Welcome page</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5">

</body>
</html>