<?php 

session_start();
if(isset($_SESSION['user1'])&& !empty($_SESSION['user1']))
{
	echo 'you are logged in.<a href="logout.php">Logout</a>';
	die();
}

else
{
	if(isset($_POST['username']) && isset($_POST['password'])) 
{
	
if(!empty($_POST['username']) && !empty($_POST['password']))

{$username=$_POST['username'];
$password=$_POST['password'];

$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';

if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project')){
die("Could not connect");
}

$query="SELECT Id from users_1 where Usename='$username' AND Passwod='$password'";

if($query_run=mysql_query($query))
{
    if(mysql_num_rows($query_run)==0)
    	echo "Invalid Username and Password";
    else if(mysql_num_rows($query_run)==1)

    {  
    	
    	$_SESSION['user1']=$username;
    	header('Location:Start.php');
    }

}

}
else
{	
echo "Enter the fields";
}
}
}
?>
<html>
<head>
	<title>Aunthenticated User Access to Admin
	</title>
	<style type="text/css">
  h1 {background-color: #ccc;
-moz-border-radius: 5px;
-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px;" }
  </style>
</head>
<body bgcolor="#e5e5e5">
	<center><h1>Aunthenticated User Access to Admin</h1></center>
	<br><br>
	<center>
		<form action="lesson2.php" method="POST">
		Username:<input type="text" name="username" placeholder="username">
		Password:<input type="password" name="password" placeholder="password">
		<input type="submit" value="Login">
       <br><br><br>
       


	</form>
	<a href="../index.php"><h2>Back</h2></a>
	<a href="../../index.php"><h2>Home</h2></a>


	<h2> Cant Bypass Authentication by typing admin.php in url :P</h2>
</center>


</body>
</html>

