
<?php
session_start();
echo"<html><body bgcolor='#e5e5e5'></body></html>";
if(!isset($_SESSION['user1']) && empty($_SESSION['user1']))
{
	header("Location:lesson2.php");
}
else
{
	echo "<center><h1>Welcome admin :D :D<h1></center> ";
}
?>
<html>
<head>
	<title>Admin page</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5">

</body>
</html>