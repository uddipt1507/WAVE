<?php
echo"<html><body bgcolor='#e5e5e5'></body></html>";
echo "<center><h1>Welcome admin :D :D<h1></center> ";

?>
<html>
<head>
	<title>Admin page</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5">

</body>
</html>