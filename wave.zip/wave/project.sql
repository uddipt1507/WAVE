-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2015 at 10:34 AM
-- Server version: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `csrf`
--

CREATE TABLE IF NOT EXISTS `csrf` (
  `Id` int(5) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Account_id` bigint(20) NOT NULL,
  `Amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `csrf`
--

INSERT INTO `csrf` (`Id`, `Username`, `Password`, `Name`, `Account_id`, `Amount`) VALUES
(1, 'admin', 'password', 'Sameer', 1102, 30000),
(2, 'admin2', 'password2', 'Rohit', 1108, 70000);

-- --------------------------------------------------------

--
-- Table structure for table `csrf3`
--

CREATE TABLE IF NOT EXISTS `csrf3` (
  `Username` varchar(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `csrf3`
--

INSERT INTO `csrf3` (`Username`, `Name`, `Message`) VALUES
('admin', 'Sameer', 'Nice one');

-- --------------------------------------------------------

--
-- Table structure for table `hijack`
--

CREATE TABLE IF NOT EXISTS `hijack` (
  `Message` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hijack`
--

INSERT INTO `hijack` (`Message`) VALUES
('This is fine');

-- --------------------------------------------------------

--
-- Table structure for table `jack`
--

CREATE TABLE IF NOT EXISTS `jack` (
  `Id` int(11) NOT NULL,
  `Fname` varchar(30) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Day` int(11) NOT NULL,
  `Month` varchar(30) NOT NULL,
  `Year` int(11) NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jack`
--

INSERT INTO `jack` (`Id`, `Fname`, `Lname`, `Email`, `Password`, `Day`, `Month`, `Year`, `Gender`) VALUES
(1, 'Sameer', 'Singh', 'sam@gmail.com', 'password', 23, 'November', 1993, 'Male'),
(2, 'Rohit', 'Mehra', 'rohit.m@gmail.com', 'password2', 30, 'May', 1992, 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `union1`
--

CREATE TABLE IF NOT EXISTS `union1` (
  `Id` int(11) NOT NULL,
  `Interest` varchar(10) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Username` varchar(10) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `union1`
--

INSERT INTO `union1` (`Id`, `Interest`, `Gender`, `Username`, `Password`) VALUES
(1, 'Badminton', 'Female', 'admin', 'Pa$$woRd'),
(2, 'Football', 'Male', 'admin2', 'paSSwOrd');

-- --------------------------------------------------------

--
-- Table structure for table `users_1`
--

CREATE TABLE IF NOT EXISTS `users_1` (
  `Id` int(4) NOT NULL,
  `Usename` varchar(20) NOT NULL,
  `Passwod` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_1`
--

INSERT INTO `users_1` (`Id`, `Usename`, `Passwod`) VALUES
(1, 'admin', 'password'),
(2, 'admin2', 'password2');

-- --------------------------------------------------------

--
-- Table structure for table `xss`
--

CREATE TABLE IF NOT EXISTS `xss` (
  `Message` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `xss`
--

INSERT INTO `xss` (`Message`) VALUES
('<script>alert("hello");</script>');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
