<?php

$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';
echo '<html>
<head>
	<title>Stored XSS</title>
</head>
<style>
#ad
{
	float:right;
	
}
</style>
<body bgcolor="#e5e5e5">
Enter your comment 
<form action="" method="GET">
	<textarea rows="4" cols="50" name="comment">
    </textarea><br>
	<input type="submit" value="Post">
</form>

<a href="lesson1.php"><h2>Back</h2><br></a>
</body>
</html>';
if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project')){
die("Could not connect");
}

if(isset($_GET['comment'])&& !empty($_GET['comment']))
{
$comment=$_GET['comment'];
$query1="INSERT INTO `project`.`XSS`(`Message`) VALUES ('$comment');";
if($queryrun=mysql_query($query1))
{
	echo "Comment posted";
}
}

echo "<u><b><br>All Comments</b></u><br>";
$query="Select * from XSS";
echo "<h4>Comment<br></h4>";
if($query_run=mysql_query($query))
{ 
	while($row=mysql_fetch_array($query_run))
{

$msg=$row['Message'];
echo "$msg<br><br>";
}
}




?>

