<html>  <!--script lower case and upper both-->
<head>
	<title>Type 2</title>
</head>
<body bgcolor="#e5e5e5" topmargin="20" leftmargin="20" rightmargin="20" >
<form action="" method="POST">
	Enter the text to search for <br>
  <input type="text" name="search"><br><br>
  <input type="submit" value="Search">

</form>
<a href="lesson1.php"><h3>Back</h3></a>

</body>
</html>
<?php
if(isset($_POST['search']) && !empty($_POST['search']))
{
	$search=$_POST['search'];
	$search=str_replace('script', null, $search);
	$search=str_replace('SCRIPT', null, $search);
	echo "<br>You searched for ".$search;
}

?>
