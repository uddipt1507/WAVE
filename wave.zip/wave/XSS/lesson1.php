<html>
<head>
	<title>Reflected XSS</title>
</head>


<body bgcolor="#e5e5e5">
	<center><h1><u>Reflected XSS</u></h1></center>
	<h2><u>Select type to open:</u></h2>

	<ul>

	<li><a href="type1.php">Type 1:No filtering</a></li><br>
	<li><a href="type2.php">Type 2:SCRIPT and script are filtered</a></li><br>
	<li><a href="type3.php">Type 3:Script(lowercase,uppercase combinations)is filtered</a></li><br>
	<li><a href="type4.php">Type 4:Tags are filtered</a></li><br>
	
    </ul>

</form>

<a href="index.php"><h3>Back</h3></a>

</body>
</html>