<html>
<head>
	<title>
		Vulnerable Web Application
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
	text-align: center;
font-size:20px;

}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;




}
#c{
	font-size: 20px;
}

 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Cross-Site Scripting (XSS)</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1.php" >Reflected XSS</a></li>
		<br>
     <li>Lesson 2:<a href="lesson2.php" >Stored XSS</a></li><br>
    

     <ul>
</aside>	
<section class="content">
<span id="c"><b>What is Cross-Site Scripting (XSS)?</b></span><br>

<p>XSS flaws occur whenever an application takes untrusted data and sends it to a web browser without proper validation or escaping. XSS allows attackers to execute scripts in the victim’s browser which can hijack user sessions, deface web sites, or redirect the user to malicious sites</p><br><br><br><br>
 <span id="c"><b>What is the vulnerability?</b></span><br>


<p>Cross-Site Scripting or XSS is a type of web application vulnerability using which code can be executed on client's web 
	browser. The code gets executed in web browser because the web application does not properly validate or sanitize the 
	input data. An application failing to filter or validate the input because of which code can be executed on a user's web 
	browser is called Cross-Site Scripting. This vulnerability is not just restricted to pop-up boxes, but also can be used to 
	redirect a user
 to phishing sites or malware hosted web sites or can be used to create fake pages on vulnerable application's web page.
</p>

<span id="c"><b>What an attacker can do?</b></span><br>

<UL>
<li><p>A web applications takes input from malicious user. This malicious user's input is not at all filtered or it is not properly filtered. If the malicious input is added to the response to be
 sent to the user then the malicious user will be able to execute scripts on a non-suspecting user's web browser.</p>
<p>What does executing scripts means?</p>
Scripts that are executed in a web browser are JavaScript or VBScript in most cases. 
The most popular scripting language used in web browsers is JavaScript.
</li>
<br>
<li>If a malicious user is able to execute scripts on an unsuspecting user's web browser because of a vulnerable web application. Then the malicious user can redirect him/her to some other website using document.location or access cookies using document.cookies or create fake page using HTML to grab sensitive information like user credentials. And the worst of all is exploiting the web browser 
	to gain remote code execution or drop a malware.</li>
<li>Severity of this vulnerability is critical because it can be utilized by a malicious 
	user to execute huge kinds of scripts on a client’s web browser</li>
</ul>

<p><span id="c"><b>Types of XSS:</b></span><br>
<ol>
<li> Reflected XSS</li>
<li> Stored XSS</li>
<li> DOM based XSS</li>
</ol>
<ol>
<li> <b>Reflected XSS</b><br>
This type of XSS is very common in web applications. The shortcoming of reflected XSS 
is that when the injection is done then at the same time it is executed. 
If the vulnerable page is opened at some other location then it will be executed normally without XSS string in it.</li>
<li> <b>Stored XSS</b><br>
In this type of XSS the injection string is stored inside a database on the server end. 
The vulnerable page whenever fetches data from the database it also fetches the injection string. 
Then it is added to the response content. When this response is viewed by any user the injection string
 gets executed on the viewer's web browser. This XSS type is very serious because an attacker has a huge
  attack surface to write a malicious script and store it in the server's database. </li>
<li><b>DOM based XSS</b><br>
DOM stands for Document Object Model. This XSS type is exactly what its name suggests. A web application suffers from this type of XSS when it cannot filter the user input which is further used by a script in the page. This vulnerability allows an attacker to modify the document object model of the web browser. The main difference between this type of XSS and others is that in other XSS types the injection string is sent to the server and the response from the server contains the injection string. But in DOM based XSS the injection string is NOT present in the response from server. 
The injection string is used by a script in page which causes unexpected behavior from the web application.
</li>
</p>
</section>
</body>
</html>