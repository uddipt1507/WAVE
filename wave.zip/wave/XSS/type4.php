<html>   <!-- tags are disabled-->
<head>
	<title>Type 4</title>
</head>
<body bgcolor="#e5e5e5" topmargin="20" leftmargin="20" rightmargin="20" >
<form action="type7.php" method="POST">
	Enter the image url<br>
  <input type="text" name="text" 
  value="
  <?php
if(isset($_POST['text']) && !empty($_POST['text']))
{
 $text=strip_tags($_POST['text']);
echo $text;

} 
else{echo 'enter text';}
?>
">
<br><br>
  <input type="submit" value="Submit">

</form>
<a href="lesson1.php"><h3>Back</h3></a>

</body>
</html>
<!--
if(isset($_POST['text']) && !empty($_POST['text']))
{
 $text=$_POST['text'];
 echo '<script>
document.getElementByName("text").value=<?php //echo $text?>;
</script>
 ';

}




xss
1.<script type='text/javascript'>

document.forms[0].onclick = function() {
alert('hello');
}

</script>

2.<body onload="document.forms[0].onclick=alert(0)">;
*/
-->
