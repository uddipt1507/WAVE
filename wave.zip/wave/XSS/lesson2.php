<html>
<head>
	<title>Stored XSS</title>
</head>


<body bgcolor="#e5e5e5">
	<center><h1><u>Stored XSS</u></h1></center>
	<h2><u>Select type to open:</u></h2>

	<ul>

	<li><a href="type5.php">Type 1:No filtering</a></li><br>
	
	
    </ul>

</form>
<a href="index.php">Back</a>

</body>
</html>