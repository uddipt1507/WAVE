<?php
require_once "../core.php";
if(loggedin())
{
    echo 'you are logged in.<a href="logout.php">Logout</a>';
    die();
}
?>
<html>
<head>
    <title>Lesson1 </title>
    <style>
h1 {background-color: #ccc;

border: 1px solid #000;
padding: 10px; }
    
    </style>
</head>

<body bgcolor="#e5e5e5">
    <center><h1>Welcome to Club Bank </h1>
        <br>
</body>

    
</html>
<?php 

require_once("../connect.php");
require_once("../login.php");

if(isset($_GET['username']) && isset($_GET['password'])) 
{
	
if(!empty($_GET['username']) && !empty($_GET['password']))

{$username=$_GET['username'];
$password=$_GET['password'];



$query="SELECT * from csrf where Username='$username' AND Password='$password' limit 0,1";

if($query_run=mysql_query($query))
{
    if(mysql_num_rows($query_run)==0)
    	echo "Invalid Username and Password";
    else if(mysql_num_rows($query_run)==1)

    {  
    	$user_id=mysql_result($query_run, 0 ,Id);
    	$name=mysql_result($query_run, 0 ,Name);
    	$account=mysql_result($query_run, 0 ,Account_id);
    	$amount=mysql_result($query_run, 0 ,Amount);
        $_SESSION['user']=$name;
    	$_SESSION['name']=$name;
    	$_SESSION['account']=$account;
    	$_SESSION['amount']=$amount;

    	header('Location:Start.php');
    }
    else
    {
    	echo "More than one field"; 
    }

}

}
else
{	
echo "Enter the fields";
}
}

?>




