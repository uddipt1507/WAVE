<?php

require '../core.php';
if(!loggedin())
{
	header('Location:lesson1.php');
}
$name=$_SESSION['name'];
$account=$_SESSION['account'];
$amount=$_SESSION['amount'];
?>
<html>
<head>
	<title>Lesson1 </title>

	<style>
h1 {background-color: #ccc;

border: 1px solid #000;
padding: 10px; }

h2{
	background-color: #ccc;

border: 1px solid #000;
padding: 10px;
width:20%;
}

#ad{
	float:right;
	
}

</style>


</head>
<body bgcolor="#e5e5e5">
<div id ="main">
	<a href="logout.php">Logout</a>
	<center><h1>Welcome To CLub Bank</h1>
	</center>
<div id="fr">
<a target="_blank" href="x.php">
<img src="ad.gif" height="250" width="350" id="ad"></img><br>
</a>
</div>


<div id="content1">

	<h2>Money Transfer</h2><br>
	<form action=account.php method="GET">
Transfer To <input type="text" name="to"><br>
Amount <input type="text" name="amount"><br>
<input type="submit" value="Send">
</form>
</div>	

<div id="content2">
	<h2>Your account status</h2><br>
	Account holder : <?php echo $name;?><br>
    Account Id:<?php echo $account;?><br>
    Account Amount:<?php echo $amount;?>

</div>
<br>

</div>
</body>
</html>

