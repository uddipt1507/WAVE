<?php
session_start();
require_once("../connect.php");
$money=$_GET['amount'];
$to=$_GET['to'];
$new_amount=$_SESSION['amount']-$money;
$account=$_SESSION['account'];
$query="Update csrf set Amount='$new_amount' where Account_Id='$account'";
if($query_run=mysql_query($query))
{
	echo $money." is successfully transferred to  ".$to ;
}
$_SESSION['amount']=$new_amount;
echo '<a href="Start.php">Back</a>';
?>