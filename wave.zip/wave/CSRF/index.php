<html>
<head>
	<title>
		CSRF
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
	text-align: center;
font-size:20px;

}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;




}
#c{
	font-size: 20px;
}

 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Cross-Site Request Forgery</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
	<ul>
		<li>
	Lesson 1:<a href="lesson1.php" >CSRF in Bank</a></li>
		<br>
     <li>Lesson 2:<a href="lesson2.php" >Logout from gmail</a></li><br>
     <li>Lesson 3:<a href="lesson3.php" >Posting Comment</a></li>

     <ul>
</aside>	
<section class="content">
<span id="c"><b>What is Cross-Site Request Forgery?</b></span><br>

<p>Application functions related to authentication and session management are often not implemented correctly, 
	allowing attackers to compromise passwords, keys, or session tokens, or to
 exploit other implementation flaws to assume other users? Identities.</p><br><br><br><br>
 <span id="c"><b>What is the vulnerability?</b></span><br>


<p>Cross-Site Request Forgery or CSRF is a type of web application vulnerability in which forged requests can be sent without user's consent. In information security industry, this vulnerability has been categorized for authenticated users. An attacker can send forged requests by hosting a malicious script somewhere which when opened sends forged request for a vulnerable web application.
</p>
<p>
	This vulnerability is mostly found in change password, profile update, change email address, etc. CSRF protection mechanism like Captcha or CSRF token are implemented but due to development flaws sometimes the developer fails to implement checking of these protection mechanisms. Sometimes the CSRF token used is predictable due to which forged requests can still be sent.
	</p>
<span id="c"><b>What an attacker can do?</b></span><br>

<UL>
<li>A vulnerable form consists of a form which does not contain any CSRF protection mechanism.</li>
<li>A malicious user can create a page which on opening sends a forged request to the page vulnerable to CSRF.</li>
<li>If the user opening this malicious page is logged-in to the vulnerable web application then the forged request is sent without his/her consent</li>
<li>CSRF protection is implemented in the web application but it is not checked properly dues to which CSRF is still possible.</li>
</ul>
</section>





</body>
</html>