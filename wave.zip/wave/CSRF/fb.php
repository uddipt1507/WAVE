<?php
session_start();
require_once("../connect.php");
echo '<html>
<head>
	<title>Comment Page</title>
</head>
<style>
#ad
{
	float:right;
	
}
</style>
<body>
<div id="fr">
<a target="_blank" href="y.php">
<img src="ad.gif" height="250" width="350" id="ad"></img><br>
</a>

	
</div>
	Enter your comment 
<form action=fb.php method="GET">
	<textarea rows="4" cols="50" name="comment">
    </textarea><br>
	<input type="submit" value="Post">
</form>

<a href="lesson3.php"><h2>Back</h2><br></a>
</body>
</html>';


if(isset($_GET['comment'])&& !empty($_GET['comment']))
{
$comment=$_GET['comment'];
$username=$_SESSION['username'];
$name=$_SESSION['name'];
$query1="INSERT INTO `project`.`csrf3`(`Username`, `Name`, `Message`) VALUES ('$username','$name','$comment');";
if($queryrun=mysql_query($query1))
{
	echo "Comment posted";
}
}

echo "<u><b><br>All Comments</b></u><br>";
$query="Select * from csrf3";
echo "<h4>Username&nbsp;&nbsp;Comment<br></h4>";
if($query_run=mysql_query($query))
{ 
	while($row=mysql_fetch_array($query_run))
{
$user=$row['Name'];
$msg=$row['Message'];
echo "$user&nbsp;&nbsp;$msg<br><br>";
}
}




?>

