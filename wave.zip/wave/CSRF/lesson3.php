<html>
<head>
    <title>Lesson 3 </title>
    <style>
h1 {background-color: #ccc;

border: 1px solid #000;
padding: 10px; }
    
    </style>
</head>

<body bgcolor="#e5e5e5">
    <center><h1>Welcome </h1>
        <br>
</body>

    
</html><?php 
session_start();
require_once("../connect.php");
require_once("../login.php");
if(isset($_GET['username']) && isset($_GET['password'])) 
{
	
if(!empty($_GET['username']) && !empty($_GET['password']))

{$username=$_GET['username'];
$password=$_GET['password'];
$query="SELECT * from csrf where Username='$username' AND Password='$password' limit 0,1";

if($query_run=mysql_query($query))
{
    if(mysql_num_rows($query_run)==0)
    	echo "Invalid Username and Password";
    else if(mysql_num_rows($query_run)==1)

    {  
    	$user_id=mysql_result($query_run, 0 ,Id);
        $user=mysql_result($query_run,0,Username);
    	$name=mysql_result($query_run, 0 ,Name);
    	$account=mysql_result($query_run, 0 ,Account_id);
    	$amount=mysql_result($query_run, 0 ,Amount);
        $_SESSION['username']=$user;
    	$_SESSION['name']=$name;
    	$_SESSION['account']=$account;
    	$_SESSION['amount']=$amount;

     header('Location:fb.php');
    }
    else
    {
    	echo "More than one field"; 
    }

}

}
else
{	
echo "Enter the fields";
}
}

?>




