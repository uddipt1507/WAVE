<html>
<head>
	<title>
	Security Misconfiguration
	</title>
<style type="text/css">
  
 body{display:block;font-family:Calibri;background:#e5e5e5}
 h1 {background-color: #ccc;
-moz-border-radius: 5px;

-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px; }

.panel
{
padding:5px;
text-align:center;
background-color:#ccc;
border:solid 1px #000;

}
.panel
{
padding:50px;
display:none;
}
.flip{
font-size:120%;
}
.lessons{
width:255px;
float:left;
padding:10px;
font-size:15px;

border: 1px solid #000;
background-color:#ccc;
margin-right:10px;
}
.h{
font-size:20px;
}
.content
{
padding-top:10px;
padding-left:10px;
padding-right:10px;
}
#c{
	font-size: 20px;
}
 </style>


</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

	<center><h1>Security Misconfiguration</h1></center>
	<a href="../index.php"><h3>Home</h3></a>
    <aside class="lessons">
	<span class="h"><u><center>Lessons</center></u></span>
  <uL>
    <li>
	Lesson 1:<a href="lesson1/lesson1.php" >Unhandled Exception</a></li>
		<br>
    <li>
     Lesson 2:<a href="lesson2/lesson2.php" >Directory Listing</a>
   </li>
 <br>
 <li>
     Lesson 3:<a href="lesson3/lesson3.php" >SQL Error</a></div>  
   </li><br>
   <li>
     Lesson 4:<a href="lesson4.php" >Brute Force Attack</a></div>  
   </li>
</aside>	
<section class="content">
<span id="c"><b>What is Security Misconfiguration?</b></span><br>

<p>Good security requires having a secure configuration defined and deployed for the application, frameworks, application server, web server, 
	database server, and platform. Secure settings should be defined, implemented, and maintained, as defaults are often insecure.
 Additionally, software should be kept up to date. </p>

 <br><br><br><br><br>
 <span id="c"><b>What is the vulnerability?</b></span><br>
 <p>Security Misconfiguration as its name suggests is a vulnerability that might occur in a web application or the web server 
 configuration or database server configuration or any internal detail made available to external entities. Security misconfiguration
  mainly occurs when configuration of an application or deployed software is not done properly leaving behind loopholes leading to 
  exploitation.</p>
<span id="c"><b>What an attacker can do?</b></span><br>
<ul>
	<li>
 The web server deployed is installed in its default configuration and no hardening has been done.</li>
 <li>
 The application server uses default username password for admin/manager accounts.</li>
<li>The database server is not up-to-date leading to remote exploitation.</li>
<li>Example files or demo files that come with web server software are not removed after installation.</li>
 <li>The web application does not handle expectations properly leading to disclosure of internal details like source code snippets, SQL 
 	queries, internal path, etc.</li>
<li>Directory listing is enabled due to which contents of a directory in document root (where web application's files are placed) is visible.</li>
</ul>
<span id="c"><b>How to secure?</b></span><br>
<p><b>PHP Security configuration: Go to PHP.INI file in xampp\php\php.ini and do the following :</b></p>
<ol>
<li>
  <p><b>Disable PHP Information</b> :change expose_php = Off</p>
 </li>
  <li>
    <p><b>Log all the Errors</b> :change Log_errors = On </p>
  </li>
  <li>
    <p><b>Disallow File Uploads</b> : change File_upload = Off</p>
  </li>
  <li>
    <p><b>Disallow Remote Code Execution</b> : change allow_url_fopen=Off <br>
allow_url_include=Off
</p>
  </li>
  <li>
    <p><b>Disallow Remote Code Execution</b>: change allow_url_fopen=Off<br>
allow_url_include=Off
</p>
  </li>
  <li>
    <p><b>Disabling Privileged Functions</b> : disable_functions=shell_exec
      , system, passthru, exec, curl_exec, proc_open, proc_close,
       curl_multi_exec, show_source, parse_int_file</p>
  </li>
  <li>
    <p><b>Limit PHP access to file system </b>: change open_basedir = /htdocs</p>
  </li>
  <li>
    <p><b>Disable Error Reporting</b> : change Display_errors = Off </p>
  </li>
</ol>
  <p><b>Apache Security Configuration:Go to httpd-default.conf file inxampp\apache\conf\extra\httpd-default.conf and do the following :</b></p>
  <ol> 
    <li><b>DENY ALL</b> : <pre>&lt;directory&gt;
AllowOverride None
Order Deny, Allow
Deny from all 
&lt;/directory&gt;
</pre>
</b>
</li>
<li><b>Trace Method</b> :TraceEnable Off</li>
<li><b>ServerSignature</b> :ServerSignature Off</li>
<li><b>ServerToken</b> : ServerTokens prod </li>
</ol>








  </ol>



</section>


	



</body>
</html>