<?php
require '../../core.php';
if(!loggedin())
{
	header('Location:lesson4.php');
}

?>

<html>
<head>
	<title>Welcome page</title>
</head>
<body>
	<center><h1>Welcome</center>

<a href="logout.php">Logout</a>

</body>
</html>