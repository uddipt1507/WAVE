<html>
<head>
	<title>SQL Error</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

</body>
</html><?php
$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';

if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project')){
die("Could not connect");
}
$query="SELECTS * from users_1 where Usename='admin'";
$query_run=mysql_query($query) or die(mysql_error());
?>
