<?php
if (isset($_POST['submit']))
{ 
$target_dir = "uploads/";
$target_file = $target_dir .basename($_FILES['fileToUpload']['name']);

    
//move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)
 if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
 {
    echo "The file ". $target_dir .basename($_FILES['fileToUpload']['name']). " has been uploaded.";
    } 
else {
        echo "Sorry, there was an error uploading your file.";
    }

}

?>
<html>
<head>
	<title>Arbitrary File Upload</title>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data">
    <input type="file" name="fileToUpload"><br><br>
    <input type="submit" name="submit" value="Submit">
</form>
   
</body>
</html>



