<html>
<head>
	<title>Menu Page</title>
<?php
if(isset($_GET['theme']))
{   $theme=$_GET['theme'];
	switch($theme){
		case '1':include_once "1.php";
		       break;
		case '2':include_once "2.php";
		         break;
		case '3':include_once "3.php";
		         break;
	}
}
if(isset($_GET['page']))
{
	$page=$_GET['page'];
	$theme=$_GET['theme'];
   
	include "$page";
	include "$theme";

	
exit();

	
    
}
?>

	<link rel="stylesheet" href="styles.css">

<style>
p{
	font-style:<?php echo $font_style;?>
	font-size:<?php echo $font_size;?>
}
body
{
background-color: <?php echo $color;?>
}
</style>
</head>
<body>
	<center>
		<p>Select a page to go into </p>
		<ul>
			<li><a href="theme.php?page=lesson1.php&theme=<?php echo $theme.'.php'?>">Lesson1</a>
			</li>
			<li><a href="theme.php?page=lesson2.php&theme=<?php echo $theme.'.php'?>">Lesson2</a>
			</li>
			<li><a href="theme.php?page=index.php&theme=<?php echo $theme.'.php'?>">Index page</a>
			</li>
		</ul>
	</center>


</body>
</html>