<?php

?>
<html>
<head>
	<title>Local File Inclusion</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >
	<center>
<p>Choose a theme from the following</p>
<ul>
	<li><a href="theme.php?theme=1">Theme 1</li>
	<li><a href="theme.php?theme=2">Theme 2</li>
	<li><a href="theme.php?theme=3">Theme 3</li>


</ul>
</center>
</body>
</html>