
<html>
<head>
	<title></title>
	<style>
p{
	font-style:italic;
	font-size:100%;
}
body
{
background-color:#aa8cc5;
}
</style>
</head>
<body>

</body>
</html>