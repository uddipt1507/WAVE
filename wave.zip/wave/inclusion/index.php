 <html>
 <head>
 	<title>File Inclusion Vulnerability</title>
 </head>
 <body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5">
 <ul>
<li>
Lesson 1:<a href="lesson1.php" >Arbitrary File Upload</a></li>
     <br>
     <li>Lesson 2:<a href="lesson2.php" >Local File Inclusion</a></li>
 </li>
</ul>
</body>
</html>