<?php

// Name of the file
$filename = 'project.sql';
// MySQL host
$mysql_host = 'localhost';
// MySQL username
$mysql_username = 'root';
// MySQL password
$mysql_password = '';

// Database name
$mysql_database = 'project';

// Connect to MySQL server
mysql_connect($mysql_host, $mysql_username, $mysql_password) or die('Error connecting to MySQL server: ' . mysql_error());
$query1="Drop database project";
$query="Create database project";
mysql_query($query1);
mysql_query($query);

// Select database
mysql_select_db($mysql_database) or die('Error selecting MySQL database: ' . mysql_error());

// Temporary variable, used to store current query
$templine = '';
// Read in entire file
$lines = file($filename);
// Loop through each line
foreach ($lines as $line)
{
// Skip it if it's a comment
if (substr($line, 0, 2) == '--' || $line == '')
    continue;

// Add this line to the current segment
$templine .= $line;
// If it has a semicolon at the end, it's the end of the query
if (substr(trim($line), -1, 1) == ';')
{
    // Perform the query
    mysql_query($templine) or print('Error performing query \'<strong>' . $templine . '\': ' . mysql_error() . '<br /><br />');
    // Reset temp variable to empty
    $templine = '';
}
}


?>
<html>
<head>
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
</head>
<body bgcolor="#e5e5e5"><center><h1>WEB APPLICATION VULNERABILITIES EXPLIANER</h1><center><br><br>

<!-- Start WOWSlider.com BODY section -->

<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/1.jpg" alt="1" title="1" id="wows1_0"/></li>
		<li><img src="data1/images/10.jpg" alt="10" title="10" id="wows1_1"/></li>
		<li><img src="data1/images/11.jpg" alt="11" title="11" id="wows1_2"/></li>
		<li><img src="data1/images/12.jpg" alt="12" title="12" id="wows1_3"/></li>
		<li><img src="data1/images/13.png" alt="13" title="13" id="wows1_4"/></li>
		<li><img src="data1/images/2.jpg" alt="2" title="2" id="wows1_5"/></li>
		<li><img src="data1/images/3.jpg" alt="3" title="3" id="wows1_6"/></li>
		<li><img src="data1/images/4.jpg" alt="4" title="4" id="wows1_7"/></li>
		<li><img src="data1/images/5.jpg" alt="5" title="5" id="wows1_8"/></li>
		<li><img src="data1/images/6.jpg" alt="6" title="6" id="wows1_9"/></li>
		<li><a href="http://wowslider.com/vi"><img src="data1/images/7.jpg" alt="carousel jquery" title="7" id="wows1_10"/></a></li>
		<li><img src="data1/images/8.jpg" alt="8" title="8" id="wows1_11"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="1"><span><img src="data1/tooltips/1.jpg" alt="1"/>1</span></a>
		<a href="#" title="10"><span><img src="data1/tooltips/10.jpg" alt="10"/>2</span></a>
		<a href="#" title="11"><span><img src="data1/tooltips/11.jpg" alt="11"/>3</span></a>
		<a href="#" title="12"><span><img src="data1/tooltips/12.jpg" alt="12"/>4</span></a>
		<a href="#" title="13"><span><img src="data1/tooltips/13.png" alt="13"/>5</span></a>
		<a href="#" title="2"><span><img src="data1/tooltips/2.jpg" alt="2"/>6</span></a>
		<a href="#" title="3"><span><img src="data1/tooltips/3.jpg" alt="3"/>7</span></a>
		<a href="#" title="4"><span><img src="data1/tooltips/4.jpg" alt="4"/>8</span></a>
		<a href="#" title="5"><span><img src="data1/tooltips/5.jpg" alt="5"/>9</span></a>
		<a href="#" title="6"><span><img src="data1/tooltips/6.jpg" alt="6"/>10</span></a>
		<a href="#" title="7"><span><img src="data1/tooltips/7.jpg" alt="7"/>11</span></a>
		<a href="#" title="8"><span><img src="data1/tooltips/8.jpg" alt="8"/>12</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.com/vi">javascript slideshow</a> by WOWSlider.com v7.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
<center>Tables imported successfully<br><br> 
<a href="index.php">Back</a></center>
<body>
</html>