<html>
<head>
  <title><?php echo $title;?></title>
    <script type = "text/javascript" src ="jq.js"></script>
 <script type = "text/javascript">
$(document).ready(function(){
$("input").focus(function() {
$(this).addClass("focus");
}).blur(function() {
$(this).removeClass("focus");
});
});
  </script>
<style type="text/css">
  h1 {background-color: #ccc;
-moz-border-radius: 5px;
-webkit-border-radius: 5px;
border: 1px solid #000;
padding: 10px;" }
.focus{
	background-color:#ccc;
}
  </style>

</head>


<body bgcolor="#e5e5e5">
<center><h1><?php echo $title;?></h1></center>
   <center>
    <h2>Enter to your Account</h2><br>
	<form action="" method="POST">
	Username<input type="text" name="username" placeholder="username" id="id1">
	Password<Input type="password" name="password" placeholder="password" id="id2">
    <input type="submit" value="Submit">
   </form>
   <br><br>
  <a href="index.php"><h2>Back</h2></a>
  <a href="../index.php"><h2>Home</h2></a>
</center>
</body>
</html>