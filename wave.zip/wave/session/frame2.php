<html>
<head>
	<title></title>
<script type = "text/javascript" src ="jq.js"></script>
 <script type = "text/javascript">
$(document).on('mousemove', function(e){
    $('#frame').css({
       left:  e.pageX,
       top:   e.pageY
    });
});
</script>
</head>
<body>
<div id="frame">
<iframe src="http://localhost/Lucideus/edit.php" style="
	  position:absolute;
	  
	  filter:alpha(opacity=50); 
	  opacity:0.5;" ></iframe>
</div>

</body>
</html>
width:600px;
	  height:500px;
	  filter:alpha(opacity=50); 
	  opacity:0.5; 