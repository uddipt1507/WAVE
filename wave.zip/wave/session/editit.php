<?php
include 'connect.php';
if(isset($_POST['submit']))
{   $id=$_POST['Id'];
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$password=$_POST['password'];
	$day=$_POST['day'];
	$month=$_POST['month'];
	$year=$_POST['year'];
	$gender=$_POST['gender'];
	$email=$_POST['email'];
	$query="UPDATE `jack` SET `Fname`='$fname',`Lname`='$lname'
	,`Password`='$password',`Email`='$email',`Day`='$day',`Month`='$month',`Year`='$year',`Gender`='$gender' WHERE Id=$id";
	if($query_run=mysql_query($query))
	{
		echo 'Updated sucessfully';
		
	}
	else{
		echo "Not Updated";
		
	}
}
   




?>