
<?php
require 'core.php';
if(!loggedin())
{
	header('Location:session_hijack.php');
}

?>
<html>
<head>
	<title>Welcome page</title>
</head>
<body>
	<center><h1>Welcome</center>

<a href="session_logout.php">Logout</a>

</body>
</html>