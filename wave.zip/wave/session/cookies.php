<?php
$time=time();
setcookie('username','Deepti', time()+60);

?>