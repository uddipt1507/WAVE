<html>
<head>
	<title>Session Management</title>
</head>
<body topmargin="20" leftmargin="20" rightmargin="20" bgcolor="#e5e5e5" >

<ul>
	<li><a href="lesson1.php">Session Kill</a></li><br>
	<li><a href="lesson2.php">Session hijacking</a></li><br>
	<li><a href="lesson3.php">HTTP Only</a></li>
</ul>
<a href="../index.php">Home</a>


</body>
</html>