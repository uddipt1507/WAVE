<html>
<head>
	<title>Starting page</title>
	<style>
	
	tr:hover
	{
		background-color: #ffff99;
		color:black;
		
	}
	#button1:hover
	{
		background-color: black;
		color:white;
	}
	#shrink{
  -webkit-transition:all 0.5s ease-out;
  -moz-transition:all 0.5s ease-out;
  -ms-transition:all 0.5s ease-out;
  -o-transition:all 0.5s ease-out;
  transition:all 0.5s ease-out;
}

#shrink:hover {
  -webkit-transform:scale(.9999);
  -moz-transform:scale(.9999);
  -ms-transform:scale(.9999);
  -o-transform:scale(.9999);
  transform:scale(.9999);
}

	</style>
</head>

<body>
<center><h1><u>Some Title will Goes Here</u></h1></center>
<table border="1" width="100%">
<tr >
	<th>Vulnerabiltiy Name</th>
	<th>Description</th>
	<th>Action</th>
</tr>
<tr id="shrink">
	<td>Broken Authentication and Session Management</td>
	<td>Some content will goes here</td>
	<td><input type="button" onclick="location.href='broken/index.php'" value="Begin" id="button1">
</tr>
<tr id="shrink">
	<td>Insecure Direct Object Reference</td>
	<td>Some Content will goes here</td>
	<td><input type="button" onclick="location.href='insecure/index.php'" value="Begin" id="button1" >
</tr>
<tr id="shrink">
	<td>Sensitive Data Exposure</td>
	<td>Some Content will goes here</td>
	<td><input type="button" onclick="location.href='secure/index.php'" value="Begin" id="button1">
</tr>
<tr id="shrink">
	<td>Missing Function level Acess Control</td>
	<td>Some Content will goes here</td>
	<td><input type="button" onclick="location.href='Missing/index.php'" value="Begin" id="button1">
</tr>
<tr id="shrink">
	<td>Using Component with known Vulnerability</td>
	<td>Some Content will goes here</td>
	<td><input type="button" onclick="location.href='Known/index.php'" value="Begin" id="button1">
</tr>
<tr id="shrink">
	<td>Unvalidated Redirects and Forwads</td>
	<td>Some Content will goes here</td>
	<td><input type="button" onclick="location.href='Forward/index.php'" value="Begin" id="button1">
</tr>


</table>

</body>
</html>