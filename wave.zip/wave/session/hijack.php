<?php

$mysql_host='localhost';
$mysql_user='root';
$mysql_pass='';
echo '<html>
<head>
	<title>Session Hijack</title>
</head>
<style>
#ad
{
	float:right;
	
}
</style>
<body bgcolor="#e5e5e5">
Enter your comment 
<form action="" method="GET">
	<textarea rows="4" cols="50" name="comment">
    </textarea><br>
	<input type="submit" value="Post">
</form>


</body>
</html>';
if(!mysql_connect($mysql_host,$mysql_user,$mysql_pass) || !mysql_select_db('project')){
die("Could not connect");
}

if(isset($_GET['comment'])&& !empty($_GET['comment']))
{
//$comment=mysql_real_escape_string($_GET['comment']);
$comment=$_GET['comment'];

$query1="INSERT INTO `hijack`(`Message`) VALUES ('$comment');";
$queryrun=mysql_query($query1) or die(mysql_error());
if($queryrun=mysql_query($query1))
{
	echo "Comment posted";
}
else
{
	echo "Not posted";
}
}

echo "<u><b><br>All Comments</b></u><br>";
$query="Select * from hijack";
echo "<h4>Comments<br></h4>";
if($query_run=mysql_query($query))
{ 
	while($row=mysql_fetch_array($query_run))
{

//$msg=stripslashes($row['Message']);
$msg=$row['Message'];
echo "$msg<br><br>";
}
}




?>

