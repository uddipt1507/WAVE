
<html>
<head>
	<title></title>
</head>
<body bgcolor="#e5e5e5">
	<center>
		Click to get the user agent<br><br>
<input type='button' name='Release'  onclick="document.write('<?php echo $_SERVER['HTTP_USER_AGENT']; ?>');" value='Click to show'>

</center>
</body>
</html>
