<?php

if(isset($_POST['option']))

{   
	setcookie("name", '', time() - 3600);
	$option=$_POST['option'];
	if($option=="set")
	{  	
	     //ini_set('session.use_only_cookies', 1);
		//session_set_cookie_params(0, NULL, NULL, NULL, TRUE);

		$arg="true";
		//echo '<script>document.cookie = "PHPSESSID=; expires=Thu, 01 Jan 1970 00:00:00 UTC";</script>'; 

        setcookie("PHPSESSID", '',time() - 3600);

		ini_set( 'session.cookie_httponly', 1 );
		//ini_set("url_rewriter.tags","");
		//ini_set('session.use_trans_sid', false);
    }
	else 
	{
		
		$arg=false;
		
	}

	setcookie("name","hello1",NULL,NULL,$arg);
	echo'<script>alert(document.cookie);</script>';
		
	
  


 
}
?>
<html>
<head>
	<title>HttpOnly Flag</title>
</head>
<body>
<form action="" method="POST">
	<input type="radio" name="option" value="set">SET <br><br>
	<input type="radio" name="option" value="notset">Not SET <br><br>
	<input type="submit" value="Alert Cookie">
	</form>
</body>
</html>